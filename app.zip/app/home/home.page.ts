import {Component, OnInit, ViewChild} from '@angular/core';
import {ILPService} from '../services/ilp.service';
import {AlertController, NavController, IonList} from '@ionic/angular';
import {Storage} from '@ionic/storage';

@Component({
    selector: 'app-home',
    templateUrl: 'home.page.html',
    styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {
    @ViewChild(IonList, {static: false}) slidingList: IonList;

    constructor(
        public dataService: ILPService,
        private alertCtrl: AlertController,
        private navCtrl: NavController,
        private storage: Storage) {
    }

    ngOnInit() {
        this.storage.get('introShown').then(result => {
            if (result == null) {
                this.storage.set('introShown', true);
                this.navCtrl.navigateRoot('/intro');
            }
        });
    }

    addChecklist(): void {
        this.alertCtrl.create({
            header: 'New Checklist',
            message: 'Enter the name for the new checklist:',
            inputs: [{type: 'text', name: 'name'}],
            buttons: [{text: 'Cancel'}, {
                text: 'Save', handler: data => {
                    this.dataService.createChecklist(data);
                }
            }]
        }).then(prompt => {
            prompt.present();
        });
    }

    renameChecklist(checklist): void {
        this.alertCtrl.create({
            header: 'Rename Checklist',
            message: 'Enter the new name for the checklist:',
            inputs: [{type: 'text', name: 'name'}],
            buttons: [{text: 'Cancel'}, {
                text: 'Save', handler: data => {
                    this.dataService.renameChecklist(checklist, data);
                }
            }]
        }).then(prompt => {
            prompt.present();
        });
    }


    removeChecklist(checklist): void {
        this.slidingList.closeSlidingItems().then(() => {
            this.dataService.removeChecklist(checklist);
        });
    }
}
