import { TestBed } from '@angular/core/testing';

import { ILPService } from './ilp.service';

describe('ILPService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ILPService = TestBed.get(ILPService);
    expect(service).toBeTruthy();
  });
});
