import { Component, OnInit, ViewChild } from '@angular/core';
import {AlertController, IonList } from '@ionic/angular';
import {ActivatedRoute} from '@angular/router';
import {Checklist, ChecklistItem} from './../interfaces/checklists';
import {ILPService} from '../services/ilp.service';

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.page.html',
  styleUrls: ['./item-list.page.scss'],
})
export class ItemListPage implements OnInit {

  @ViewChild(IonList, {static: false}) slidingList: IonList;
  private slug: string;
  public checklist: Checklist;

  public searchTerm: string = "";
  public items: any;

  constructor(
      private alertCtrl: AlertController,
      private route: ActivatedRoute,
      private dataService: ILPService) { }

  ngOnInit() {
    this.slug = this.route.snapshot.paramMap.get('id');
    this.loadChecklist();
    this.setFilteredItems();
  }

  setFilteredItems() {
    this.items = this.dataService.filterItems(this.searchTerm);
  }

  loadChecklist(): void {
    if (this.dataService.loaded) {
      this.checklist = this.dataService.getChecklist(this.slug);
    } else {
      this.dataService.load().then(() => {
        this.checklist = this.dataService.getChecklist(this.slug);
      });
    }
  }

  addItem(): void {
    this.alertCtrl.create({
      header: 'Add Item',
      message: 'Enter the name of the item below:',
      inputs: [{type: 'text', name: 'name'}],
      buttons: [{text: 'Cancel'}, {
        text: 'Save', handler: data => {
          this.dataService.addItem(this.checklist.id, data);
        }
      }]
    }).then(prompt => {
      prompt.present();
    });
  }

  removeItem(item): void {
    this.slidingList.closeSlidingItems().then(() => {
      this.dataService.removeItem(this.checklist, item);
    });
  }

  renameItem(item) {
    this.alertCtrl.create({
      header: 'Rename Item',
      message: 'Enter the new name of the task for the list below:',
      inputs: [{type: 'text', name: 'name'}],
      buttons: [{text: 'Cancel'}, {
        text: 'Save', handler: data => {
          this.dataService.renameItem(item, data);
        }
      }]
    }).then(prompt => {
      prompt.present();
    });
  }

  toggleItem(item) {
    this.dataService.toggleItem(item);
  }
}
